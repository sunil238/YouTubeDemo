﻿using System;
using System.Collections.Generic;
using System.Text;
using VirtoCommerce.Platform.Core.Events;
using YouTube.DemoModule.Core.Models;

namespace YouTube.DemoModule.Core.Events
{
    public class YoutubeVideoChangedEvent:DomainEvent
    {
        public List<YoutubeVideo> Video { get; set; }
    }
}
