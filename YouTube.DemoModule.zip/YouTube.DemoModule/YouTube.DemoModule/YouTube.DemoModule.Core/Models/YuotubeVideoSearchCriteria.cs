﻿using VirtoCommerce.Platform.Core.Common;

namespace YouTube.DemoModule.Core.Models
{
    public class YuotubeVideoSearchCriteria : SearchCriteriaBase
    {
        public string ProductId { get; set; }
    }
}
