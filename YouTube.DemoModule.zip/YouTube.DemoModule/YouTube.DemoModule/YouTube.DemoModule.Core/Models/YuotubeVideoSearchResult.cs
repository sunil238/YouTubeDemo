﻿using System;
using System.Collections.Generic;
using System.Text;
using VirtoCommerce.Platform.Core.Common;

namespace YouTube.DemoModule.Core.Models
{
    public class YuotubeVideoSearchResult: GenericSearchResult<YoutubeVideo>
    {
    }
}
