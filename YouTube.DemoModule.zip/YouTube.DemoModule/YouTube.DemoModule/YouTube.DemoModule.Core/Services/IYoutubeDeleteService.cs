﻿using YouTube.DemoModule.Core.Models;
using System.Threading.Tasks;

namespace YouTube.DemoModule.Core.Services
{
    public interface IYoutubeDeleteService
    {
        public string Delete(string id);
    }

}
