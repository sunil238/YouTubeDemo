﻿using YouTube.DemoModule.Core.Models;
using System.Threading.Tasks;
using System.Collections.Generic;

namespace YouTube.DemoModule.Core.Services
{
    public interface IYuotubeVideoSearchService
    {
        Task<YuotubeVideoSearchResult> Search(YuotubeVideoSearchCriteria criteria);
        Task SaveCustomerReviewsAsync(List<YoutubeVideo> items);
    }
}
