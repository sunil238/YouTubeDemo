﻿using System;
using System.Collections.Generic;
using System.Text;
using YouTube.DemoModule.Core.Models;

namespace YouTube.DemoModule.Core.Services
{
    public interface IYoutubeSaveService
    {
        public string Save(YoutubeVideo videoSave);
    }
}
