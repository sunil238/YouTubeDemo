﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using VirtoCommerce.Platform.Core.Events;
using YouTube.DemoModule.Core.Events;

namespace YouTube.DemoModule.Data.Handlers
{
    public class YoutubeDomainEventHandler: IEventHandler<YoutubeVideoChangeEvent>
    {
        public Task Handle(YoutubeVideoChangeEvent message)
        {
            //Some logic here
            return Task.FromResult(0);
        }
    }
}
