﻿using YouTube.DemoModule.Core.Models;
using System.Linq;
using VirtoCommerce.Platform.Core.Common;
using YouTube.DemoModule.Data.Models;
using System.Threading.Tasks;

namespace YouTube.DemoModule.Data.Repositories
{
    public interface IYoutubeRepository : IRepository
    {
        IQueryable<YoutubeVideo> YoutubeVideos { get; }
        IQueryable<YoutubeEntity> CustomerReviews { get; }

        Task<YoutubeEntity[]> GetByIdsAsync(string[] ids);
    }
}
