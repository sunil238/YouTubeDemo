﻿using YouTube.DemoModule.Core.Models;
using System.Linq;
using VirtoCommerce.Platform.Data.Infrastructure;
using YouTube.DemoModule.Data.Repositories;
using YouTube.DemoModule.Data.Models;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace YouTube.DemoModule.Data.Repositories
{
    public class YoutubeRepository : DbContextRepositoryBase<YouTubeDemoModuleDbContext>, IYoutubeRepository
    {
        public YoutubeRepository(YouTubeDemoModuleDbContext context) : base(context)
        {

        }

        public IQueryable<YoutubeVideo> YoutubeVideos => DbContext.Set<YoutubeVideo>();

        public IQueryable<YoutubeEntity> CustomerReviews => DbContext.Set<YoutubeEntity>();

        public async Task<YoutubeEntity[]> GetByIdsAsync(string[] ids)
        {
            return await CustomerReviews.Where(x => ids.Contains(x.Id)).ToArrayAsync();
        }
    }
}
