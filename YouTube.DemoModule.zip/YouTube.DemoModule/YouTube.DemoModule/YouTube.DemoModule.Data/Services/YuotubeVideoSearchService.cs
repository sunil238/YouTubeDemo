﻿using YouTube.DemoModule.Core.Models;
using YouTube.DemoModule.Core.Services;
using YouTube.DemoModule.Data.Repositories;
using System.Linq;
using System.Threading.Tasks;
using System;
using System.Collections.Generic;
using VirtoCommerce.Platform.Core.Common;
using YouTube.DemoModule.Data.Models;
using YouTube.DemoModule.Core.Events;
using VirtoCommerce.Platform.Core.Events;

namespace YouTube.DemoModule.Data.Services
{
    public class YuotubeVideoSearchService : IYuotubeVideoSearchService
    {
        private readonly IYoutubeRepository _repository;
        private readonly Func<IYoutubeRepository> _repositoryFactory;
        private readonly IEventPublisher _eventPublisher;
        public YuotubeVideoSearchService(IYoutubeRepository repository, IYoutubeRepository repositoryDelete, IEventPublisher eventPublisher)
        {
            _repository = repository;
            _eventPublisher = eventPublisher;
        }

        public Task<YuotubeVideoSearchResult> Search(YuotubeVideoSearchCriteria criteria)
        {
            int TotalCount1 = _repository.YoutubeVideos.Count();
            var result = new YuotubeVideoSearchResult
            {
                TotalCount = _repository.YoutubeVideos.Count(),
                Results = _repository.YoutubeVideos.Skip(criteria.Skip).Take(criteria.Take).ToArray()
            };

            return Task.FromResult(result);
        }
        public async Task SaveCustomerReviewsAsync(List<YoutubeVideo> items)
        {
            if (items == null)
                throw new ArgumentNullException(nameof(items));

            using (var repository = _repositoryFactory())
            {
                var pkMap = new PrimaryKeyResolvingMap();
                var alreadyExistEntities = await repository.GetByIdsAsync(items.Select(x => x.Id).ToArray());
                foreach (var derivativeContract in items)
                {
                    var sourceEntity = AbstractTypeFactory<YoutubeEntity>.TryCreateInstance().FromModel(derivativeContract, pkMap);
                    var targetEntity = alreadyExistEntities.FirstOrDefault(x => x.Id == sourceEntity.Id);
                    if (targetEntity != null)
                    {
                        sourceEntity.Patch(targetEntity);
                    }
                    else
                    {
                        repository.Add(sourceEntity);
                    }
                }

                await repository.UnitOfWork.CommitAsync();
                pkMap.ResolvePrimaryKeys();
            }
        //    await _eventPublisher.Publish(new YoutubeVideoChangeEvent { Video = items });
        }
        //public bool Delete(YuotubeVideoSearchCriteria criteria)
        //{
        //    using (_repositoryDelete)
        //    {

        //        foreach (var repo in _repositoryDelete.YoutubeVideos)
        //        {
        //            if (repo.ProductId.ToString() == criteria.ProductId.ToString())
        //            {
        //                _repositoryDelete.Remove(repo);
        //                _repository.Dispose();
        //                _repositoryDelete.UnitOfWork.Commit();
        //                return true;
        //            }
        //        }
        //    }
        //     return false;
        //}

    }
}

