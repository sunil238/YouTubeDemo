﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using VirtoCommerce.Platform.Core.Events;
using YouTube.DemoModule.Core.Events;
using YouTube.DemoModule.Core.Models;
using YouTube.DemoModule.Core.Services;
using YouTube.DemoModule.Data.Repositories;

namespace YouTube.DemoModule.Data.Services
{
    public class YoutubeSaveService: IYoutubeSaveService
    {
        private readonly IYoutubeRepository _repository;
        private readonly IEventPublisher _eventPublisher;
        public YoutubeSaveService(IYoutubeRepository repository, IEventPublisher eventPublisher)
        {
            _repository = repository;
            _eventPublisher = eventPublisher;
        }
        public string Save(YoutubeVideo videoSave)
        {
            try
            {
                if(videoSave.Id == null)
                {
                    videoSave.Id = videoSave.ProductId;
                }

                var item = _repository.YoutubeVideos.Where(q => q.ProductId == videoSave.Id).FirstOrDefault();
                if (item == null)
                {
                    videoSave.ProductId = videoSave.Id;
                    videoSave.CreatedDate = DateTime.Now;
                    YouTubeDemoModuleDbContext context = new YouTubeDemoModuleDbContext();
                    context.YoutubeVideos.Add(videoSave);
                    context.SaveChanges();
                    _eventPublisher.Publish(new YoutubeVideoChangeEvent { Video = videoSave });
                    return "Success";
                    
                }

                _eventPublisher.Publish(new YoutubeVideoChangeEvent { Video = videoSave });
                return "Failed";
                
            }
            catch (System.Exception e)
            {

                return e.Message;
            }
        }
    }
}
