﻿using System;
using System.Collections.Generic;
using System.Text;
using VirtoCommerce.Platform.Core.Caching;

namespace YouTube.DemoModule.Data.Caching
{
    public class YoutubeVideoCacheRegion: CancellableCacheRegion<YoutubeVideoCacheRegion>
    {
    }
}
