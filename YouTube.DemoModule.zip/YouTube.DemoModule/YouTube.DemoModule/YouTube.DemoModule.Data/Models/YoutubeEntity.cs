﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;
using VirtoCommerce.Platform.Core.Common;
using YouTube.DemoModule.Core.Models;

namespace YouTube.DemoModule.Data.Models
{
    public class YoutubeEntity : AuditableEntity
    {
        [StringLength(128)]
        public string Link { get; set; }

        [Required]
        [StringLength(1024)]
        public string ProductId { get; set; }

        public virtual YoutubeVideo ToModel(YoutubeVideo customerReview)
        {
            if (customerReview == null)
                throw new ArgumentNullException(nameof(YoutubeVideo));

            customerReview.Id = Id;
            customerReview.CreatedBy = CreatedBy;
            customerReview.CreatedDate = CreatedDate;
            customerReview.ModifiedBy = ModifiedBy;
            customerReview.ModifiedDate = ModifiedDate;

            customerReview.VideoTitle = Link;
            customerReview.ProductId = ProductId;

            return customerReview;
        }

        public virtual YoutubeEntity FromModel(YoutubeVideo customerReview, PrimaryKeyResolvingMap pkMap)
        {
            if (customerReview == null)
                throw new ArgumentNullException(nameof(customerReview));

            pkMap.AddPair(customerReview, this);

            Id = customerReview.Id;
            CreatedBy = customerReview.CreatedBy;
            CreatedDate = customerReview.CreatedDate;
            ModifiedBy = customerReview.ModifiedBy;
            ModifiedDate = customerReview.ModifiedDate;

            Link = customerReview.VideoTitle;
            ProductId = customerReview.ProductId;

            return this;
        }

        public virtual void Patch(YoutubeEntity target)
        {
            if (target == null)
                throw new ArgumentNullException(nameof(target));

            target.Link = Link;
            target.ProductId = ProductId;
        }
    }
}
