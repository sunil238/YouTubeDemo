angular.module('youTube.demoModule')
    .controller('youTube.demoModule.videoWidgetController', ['$scope', 'youTube.demoModule.WebApi', 'platformWebApp.bladeNavigationService', function ($scope, videoApi, bladeNavigationService) {
        var blade = $scope.blade;
        var filter = { take: 0 };

        function refresh() {
            $scope.loading = true;
            videoApi.search(filter, function (data) {
                $scope.loading = false;
                $scope.totalCount = data.totalCount;
            });
        }

        $scope.openBlade = function () {
            if ($scope.loading || !$scope.totalCount)
                return;

            var newBlade = {
                id: "videoList",
                filter: filter,
                title: 'Youtube Videos for "' + blade.title + '"',
                controller: 'youTube.demoModule.videoListController',
                template: 'Modules/$(youTube.demoModule)/Scripts/blades/video-list.tpl.html'
            };
            bladeNavigationService.showBlade(newBlade, blade);
        };

        $scope.$watch("blade.itemId", function (id) {
            filter.productIds = [id];

            if (id) refresh();
        });
    }]);
