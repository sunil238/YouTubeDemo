// Call this to register your module to main application
var moduleName = "youTube.demoModule";

if (AppDependencies !== undefined) {
    AppDependencies.push(moduleName);
}

angular.module(moduleName, [])
    .config(['$stateProvider', '$urlRouterProvider',
        function ($stateProvider, $urlRouterProvider) {
            $stateProvider
                .state('workspace.youTubeDemoModuleState', {
                    url: '/youTube.demoModule',
                    templateUrl: '$(Platform)/Scripts/common/templates/home.tpl.html',
                    controller: [
                        '$scope', 'platformWebApp.bladeNavigationService', function ($scope, bladeNavigationService) {
                            var newBlade = {
                                id: 'videoList',
                                controller: 'youTube.demoModule.videoListController',
                                template: 'Modules/$(youTube.demoModule)/Scripts/blades/video-list.tpl.html',
                                isClosingDisabled: true
                            };
                            bladeNavigationService.showBlade(newBlade);
                        }
                    ]
                });
        }
    ])
    .run(['platformWebApp.mainMenuService', 'platformWebApp.widgetService', '$state', 'platformWebApp.authService',
        function (mainMenuService, widgetService, $state, authService) {
            //Register module in main menu
            var menuItem = {
                path: 'browse/youTube.demoModule',
                icon: 'fab fa-youtube',
                title: 'youTube.demoModule.title',
                priority: 100,
                action: function () { $state.go('workspace.youTubeDemoModuleState'); },
                permission: 'youTubeDemoModule:access'
            };
            mainMenuService.addMenuItem(menuItem);

            var itemVideoWidget = {
                controller: 'youTube.demoModule.videoWidgetController',
                template: 'Modules/$(youTube.demoModule)/Scripts/Widget/videoWidget.tpl.html',
                isVisible: function (blade) { return authService.checkPermission('youTubeDemoModule:access'); }
            };
            widgetService.registerWidget(itemVideoWidget, 'itemDetail');
        }
    ]);
