angular.module('youTube.demoModule')
    .controller('youTube.demoModule.helloWorldController', ['$scope', 'youTube.demoModule.webApi', function ($scope, api) {
        var blade = $scope.blade;
        blade.title = 'YouTube.DemoModule';

        blade.refresh = function () {
            api.get(function (data) {
                blade.title = 'youTube.demoModule.blades.hello-world.title';
                blade.data = data.result;
                blade.isLoading = false;
            });
        };

        blade.refresh();
    }]);
