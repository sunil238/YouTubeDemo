angular.module('youTube.demoModule')
    .controller('youTube.demoModule.addYoutubeVideoController', ['$scope', 'youTube.demoModule.WebApi', 'platformWebApp.bladeNavigationService', function ($scope, api, bladeNavigationService) {
        var blade = $scope.blade;
        blade.title = 'youTube.demoModule.blades.video-list.addVideoBlade.title';
        blade.isLoading = false;

        $scope.saveChanges = function () {
            blade.isLoading = true;

            api.add(blade.currentEntity, function (data) {
                blade.parentBlade.refresh();
                blade.parentBlade.selectNode(data)
                blade.isLoading = false;
                $scope.bladeClose()
            },
                function (error) { bladeNavigationService.setError('Error ' + error.status, blade); })
           };
    }]);
