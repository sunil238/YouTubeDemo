using YouTube.DemoModule.Core.Models;
using YouTube.DemoModule.Core.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using YouTube.DemoModule.Core;
using System.Collections.Generic;

namespace YouTube.DemoModule.Web.Controllers.Api
{
    [Route("api/YouTubeDemoModule")]
    public class YouTubeDemoModuleController : Controller
    {
        private readonly IYuotubeVideoSearchService _searchService;
        private readonly IYoutubeDeleteService _deleteService;
        private readonly IYoutubeSaveService _saveService;

        public YouTubeDemoModuleController(IYuotubeVideoSearchService searchService, IYoutubeDeleteService deleteService, IYoutubeSaveService saveService)
        {
            _searchService = searchService;
            _deleteService = deleteService;
            _saveService = saveService;
        }
        // GET: api/YouTubeDemoModule
        /// <summary>
        /// Get message
        /// </summary>
        /// <remarks>Return "Hello world!" message</remarks>
        [HttpGet]
        [Route("")]
        [Authorize(ModuleConstants.Security.Permissions.Read)]
        public ActionResult<string> Get()
        {
            return Ok(new { result = "Hello world!" });
        }
        [HttpPost]
        [Route("search")]
        [Authorize(ModuleConstants.Security.Permissions.Read)]
        public Task<YuotubeVideoSearchResult> c([FromBody] YuotubeVideoSearchCriteria criteria)
        {
            return _searchService.Search(criteria);
        }
        [HttpDelete]
        [Route("delete")]
        [Authorize(ModuleConstants.Security.Permissions.Delete)]
        public JsonResult Delete([FromBody] YuotubeVideoSearchCriteria deleteCriteria)
        {
           
            return Json(_deleteService.Delete(deleteCriteria.ProductId));
        }
        [HttpPost]
        [Route("Save")]
        [Authorize(ModuleConstants.Security.Permissions.Update)]
        public JsonResult Save([FromBody] YoutubeVideo videoSave)
        {

            return Json(_saveService.Save(videoSave));
        }
        //public async Task<ActionResult> Update([FromBody] List<YoutubeVideo> youtubevideos)
        //{
        //    await _searchService.SaveCustomerReviewsAsync(youtubevideos);
        //    return NoContent();
        //}
        //public bool Delete([FromBody] YuotubeVideoSearchCriteria deleteCriteria)
        //{

        //    return _searchService.Delete(deleteCriteria);
        //}
    }
}
