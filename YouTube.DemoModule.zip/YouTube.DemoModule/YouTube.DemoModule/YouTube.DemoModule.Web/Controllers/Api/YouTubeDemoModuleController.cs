using YouTube.DemoModule.Core.Models;
using YouTube.DemoModule.Core.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using YouTube.DemoModule.Core;
using System.Collections.Generic;

namespace YouTube.DemoModule.Web.Controllers.Api
{
    [Route("api/YouTubeDemoModule")]
    public class YouTubeDemoModuleController : Controller
    {
        private readonly IYuotubeVideoSearchService _searchService;
        private readonly IYoutubeDeleteService _deleteService;

        public YouTubeDemoModuleController(IYuotubeVideoSearchService searchService, IYoutubeDeleteService deleteService)
        {
            _searchService = searchService;
            _deleteService = deleteService;
        }
        // GET: api/YouTubeDemoModule
        /// <summary>
        /// Get message
        /// </summary>
        /// <remarks>Return "Hello world!" message</remarks>
        [HttpGet]
        [Route("")]
        [Authorize(ModuleConstants.Security.Permissions.Read)]
        public ActionResult<string> Get()
        {
            return Ok(new { result = "Hello world!" });
        }
        [HttpPost]
        [Route("search")]
        [Authorize(ModuleConstants.Security.Permissions.Read)]
        public Task<YuotubeVideoSearchResult> Search([FromBody] YuotubeVideoSearchCriteria criteria)
        {
            return _searchService.Search(criteria);
        }
        [HttpDelete]
        [Route("delete")]
        [Authorize(ModuleConstants.Security.Permissions.Delete)]
        public JsonResult Delete([FromBody] YuotubeVideoSearchCriteria deleteCriteria)
        {
           
            return Json(_deleteService.Delete(deleteCriteria.ProductId));
        }
        [HttpPost]
        [Route("add")]
        [Authorize(ModuleConstants.Security.Permissions.Update)]
        public async Task<ActionResult> Update([FromBody] List<YoutubeVideo> youtubevideos)
        {
            await _searchService.SaveCustomerReviewsAsync(youtubevideos);
            return NoContent();
        }
        //public bool Delete([FromBody] YuotubeVideoSearchCriteria deleteCriteria)
        //{

        //    return _searchService.Delete(deleteCriteria);
        //}
    }
}
